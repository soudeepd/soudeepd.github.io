
############################ T20 DATA READING AND CLEANING

# load libraries as required
library(ggplot2)
library(tidyverse)

# fix your working directory
setwd("...")

# read the match-level data from T20I matches
df <- read.csv("Cricket-T20/T20_matchinfo.csv")

# check the class of every column
unlist(sapply(df,"class"))
View(df)

# change the class of date column
df$date = as.Date(df$date)

# check NAs and remove missing values
colSums(is.na(df))
df_clean = df %>% filter(!(is.na(by_run) & is.na(by_wicket)))

# only work with data with date, gender, venue, teams, toss and result
df_clean = df %>% dplyr::select(matchid, date, gender, venue, team1, team2, 
                                toss_winner, toss_decision, result, by_run, by_wicket)


# HANDS-ON EXERCISE: Use the above data to answer the following questions.
# (1) Do teams perform better at home?
# (2) Does toss play a role in the outcome?
# (3) Are teams performing differently when batting first vs batting second?



########################## BASIC SUMMARIZATION OF DATA

# frequency distribution of home and away teams according to gender
df_clean %>%
  group_by(gender, team1, team2) %>%
  summarize(
    frequency = n()
  ) %>%
  ungroup() %>%
  View()

# problem with the above: very few matches as home/away for some countries

# create a frequency distribution for the total/home/away number of matches
allteams = union(unique(df_clean$team1), unique(df_clean$team2))
no_of_matches = home_matches = away_matches = numeric(length(allteams))
for (j in 1:length(allteams)){
  home_matches[j] = sum(df_clean$team1 == allteams[j])
  away_matches[j] = sum(df_clean$team2 == allteams[j])
  no_of_matches[j] = sum(df_clean$team1 == allteams[j]) + sum(df_clean$team2 == allteams[j])
}
data.frame(team = allteams,
           matches = no_of_matches,
           home = home_matches,
           away = away_matches) %>% View()

# create a frequency distribution of matches according to gender and test-playing nations
test_teams = c('Australia','Bangladesh','England','India','New Zealand',
               'Pakistan','South Africa','Sri Lanka','West Indies')
male_matches = female_matches = numeric(length(test_teams))
male_df = df_clean %>% filter(gender == 'male')
female_df = df_clean %>% filter(gender == 'female')
for (j in 1:length(test_teams)){
  male_matches[j] = sum(male_df$team1 == test_teams[j]) + sum(male_df$team2 == test_teams[j])
  female_matches[j] = sum(female_df$team1 == test_teams[j]) + sum(female_df$team2 == test_teams[j])
}
freq_table = data.frame(
  team = test_teams,
  male = male_matches,
  female = female_matches
) 
View(freq_table)


########################## SOME VISUALIZATION IDEAS

# extract only male matches with results
male_df = df_clean %>% filter(gender == 'male' & result != 'No result')

# create new columns to denote who batted first and who batted second
male_df = male_df %>%
  mutate(
    toss_loser = ifelse(toss_winner == team1,team2,team1),
    bat_first = ifelse(toss_decision == 'field',toss_loser,toss_winner),
    bat_second = ifelse(toss_decision == 'field',toss_winner,toss_loser)
  )

# barplot for win% by different teams in males
test_teams = c('Australia','Bangladesh','England','India','New Zealand',
               'Pakistan','South Africa','Sri Lanka','West Indies')
matches = bat_first = bat_second = numeric(length(test_teams))
tot_win = chase_win = bat_win = numeric(length(test_teams))

for (j in 1:length(test_teams)){
  matches[j] = sum(male_df$team1 == test_teams[j]) + sum(male_df$team2 == test_teams[j])
  bat_first[j] = sum(male_df$bat_first == test_teams[j])
  bat_second[j] = sum(male_df$bat_second == test_teams[j])
  tot_win[j] = sum(male_df$result == test_teams[j])/matches[j]
  chase_win[j] = sum(male_df$result == test_teams[j] & male_df$bat_second == test_teams[j])/bat_second[j]
  bat_win[j] = sum(male_df$result == test_teams[j] & male_df$bat_first == test_teams[j])/bat_first[j]
}
win_summary = data.frame(
  team = test_teams,
  matches,bat_first,bat_second,
  tot_win,chase_win,bat_win
) 

# create the barplot using ggplot2 package
win_barplot = win_summary %>%
  ggplot(aes(x = team,y = tot_win)) +
  geom_bar(stat="identity") +
  xlab("") +
  ylab("total win%") +
  theme_minimal() +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15))

# view or export plot to png file
win_barplot
ggsave(filename = "win_barplot.png",
       plot = win_barplot,
       width = 300,
       height = 200,
       units = "mm",
       dpi = 800)


# create another barplot for chase/bat first
win_summary_melt = reshape2::melt(win_summary[,c(1,5,6,7)]) # first create a new data-frame
win_barplot2 = win_summary_melt %>%
  mutate(
    variable = recode(variable,tot_win = "total",bat_win = "batting 1st",chase_win = "batting 2nd")
  ) %>%
  ggplot(aes(x = team,y = value,fill = variable)) +
  geom_bar(stat="identity",position = position_dodge()) +
  xlab("") +
  ylab("win%") +
  theme_minimal() +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15),
        legend.position = "bottom",
        legend.text = element_text(size = 15),
        legend.title = element_blank())

# view or export plot to png file
win_barplot2
ggsave(filename = "win_barplot2.png",
       plot = win_barplot2,
       width = 300,
       height = 200,
       units = "mm",
       dpi = 800)


########################## OTHER EXPLORATION

# toss decision and its effectiveness
male_df %>%
  group_by(toss_decision) %>%
  summarize(
    total = n(),
    won = sum(toss_winner == result)/n(),
    lost = sum(toss_winner != result)/n()
  )

# two-sample testing of proportion:
# find the frequencies and sample sizes of the two cases
# and use prop.test() function
male_df %>%
  group_by(toss_decision) %>%
  summarize(
    won = sum(toss_winner == result),
    total = n()
  )

prop.test(x = c(413, 443),n = c(828, 898),alternative = "two.sided")

# p-value is 0.86, thus equality is not rejected
# there is not enough evidence that toss decision matters

# create year-wise frequencies, until 2022, of T20 matches for both males and females
# then create the plot with line diagram
df_clean %>%
  filter(date < as.Date('2023-01-01')) %>%
  mutate(
    year = as.numeric(substr(date,1,4))
  ) %>%
  group_by(year) %>%
  summarize(
    male_matches = sum(gender == 'male'),
    female_matches = sum(gender == 'female')
  ) %>%
  ggplot(aes(x = year)) +
  geom_line(aes(y = male_matches,col = 'male')) + 
  geom_line(aes(y = female_matches,col = 'female')) +
  scale_color_manual(values = c('male'='red','female'='blue'),name = "") +
  xlab("Year") +
  ylab("No of matches") +
  theme_minimal() +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15),
        legend.position = "bottom",
        legend.text = element_text(size = 15))


############################ PLAYERWISE T20 DATA READING AND CLEANING

# read the T20 datasets
t20_games <- read.csv("Cricket-T20/T20_matchinfo.csv")
t20_ballbyball <- read.csv("Cricket-T20/T20_ballbyball.csv")

# check the class of every column and change them if needed
sapply(t20_games,"class")
sapply(t20_ballbyball,"class")
t20_games$date = as.Date(t20_games$date)

# extract the information of all men's matches
mens_games = t20_games %>% filter(gender == 'male')
mens_ballbyball = t20_ballbyball %>% filter(matchid %in% mens_games$matchid)

# calculate runs and wickets in two innings for all matches
match_no = nrow(mens_games)
mens_games$inn1_run = mens_games$inn1_wk = numeric(match_no)
mens_games$inn2_run = mens_games$inn2_wk = numeric(match_no)
for (j in 1:match_no){
  allballs = mens_ballbyball %>% filter(matchid == mens_games$matchid[j])
  mens_games$inn1_run[j] = sum(subset(allballs,innings == 1)$runs.total)
  mens_games$inn1_wk[j] = sum(!is.na(subset(allballs,innings == 1)$wickets.player_out))
  mens_games$inn2_run[j] = sum(subset(allballs,innings == 2)$runs.total)
  mens_games$inn2_wk[j] = sum(!is.na(subset(allballs,innings == 2)$wickets.player_out))
}

# summarize the batters' runs and other information based on matches
# there are some matches with innings 3 and 4, removing them from the data
mens_summary = mens_ballbyball %>%
  filter(innings %in% c(1,2)) %>%
  group_by(batter,matchid,innings) %>%
  summarize(
    runs = sum(runs.batter),
    balls = sum(is.na(extras.wides)),
    fours = sum(runs.batter == 4),
    sixes = sum(runs.batter == 6),
    strike_rate = 100*runs/balls
  )
N = nrow(mens_summary)

# initiate and calculate some new variables
date = as.Date(character(N))
ownteam = opponent = character(N)
home = toss_win = target_if_chase = numeric(N)
for (j in 1:N){
  matchinfo = mens_games %>% filter(matchid == mens_summary$matchid[j])
  date[j] = matchinfo$date
  team1players = matchinfo[,c('team1_player1','team1_player2','team1_player3','team1_player4',
                              'team1_player5','team1_player6','team1_player7','team1_player8',
                              'team1_player9','team1_player10','team1_player11','team1_player11')]
  team2players = matchinfo[,c('team2_player1','team2_player2','team2_player3','team2_player4',
                              'team2_player5','team2_player6','team2_player7','team2_player8',
                              'team2_player9','team2_player10','team2_player11','team2_player11')]
  ownteam[j] = ifelse(mens_summary$batter[j] %in% team1players,matchinfo$team1,matchinfo$team2)
  opponent[j] = ifelse(mens_summary$batter[j] %in% team1players,matchinfo$team2,matchinfo$team1)
  home[j] = as.numeric(matchinfo$team1 == ownteam[j])
  toss_win[j] = as.numeric(matchinfo$toss_winner == ownteam[j])
  if (mens_summary$innings[j] == 2){
    target_if_chase[j] = matchinfo$inn1_run
  }
}

# merge the new information with earlier data-frame
mens_summary = data.frame(mens_summary,date,ownteam,opponent,
                          home,toss_win,target_if_chase)

# remove NA values
mens_clean = mens_summary[complete.cases(mens_summary),]


############################ LINEAR MODEL FOR RUNS WITH MULTIPLE REGRESSORS

# an initial exploration of runs against balls with a scatter plot
mens_clean %>%
  ggplot(aes(x = balls,y = runs)) +
  geom_point() +
  xlab("Balls played") +
  ylab("Runs scored") +
  theme_minimal() +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15))


# we can look at other plots as well
mens_clean %>%
  filter(innings == 2) %>%
  ggplot(aes(x = target_if_chase,y = runs)) +
  geom_point() +
  xlab("Target") +
  ylab("Runs scored") +
  theme_minimal() +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15))

# running the linear regression
lin_model = lm(runs ~ balls + home + toss_win + target_if_chase + factor(innings),
               data = mens_clean)

# see the summary
summary(lin_model)


############################ POISSON MODEL FOR RUNS WITH MULTIPLE REGRESSORS

# run the poisson model
poi_model = glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings),
                family = poisson(link = "log"),data = mens_clean)

# see the summary
summary(poi_model)


############################ POISSON MODEL FOR RUNS WITH TEAM EFFECTS

# run the poisson model with only own team fixed effects
poiglm_own = glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings) 
                 + ownteam,
                 family = poisson(link = "log"),data = mens_clean)

# see the summary
summary(poiglm_own)

# run the poisson model with both own team and opponent fixed effects
poiglm_both = glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings) 
                  + ownteam + opponent,
                  family = poisson(link = "log"),data = mens_clean)

# see the summary
summary(poiglm_both)

# how many fixed effects are there?
length(unique(mens_clean$ownteam))
length(unique(mens_clean$ownteam)) + length(unique(mens_clean$opponent))
nrow(unique(mens_clean[,c('ownteam','opponent')]))


# is it getting better in the sense of predictability?

# divide into training data and testing data randomly
N = nrow(mens_clean)
set.seed(1)
idx = sample(N,floor(N*0.8))
train = mens_clean[idx,]
test = mens_clean[-idx,]

# fit the four different models
model1 <- glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings),
              family = poisson(link = "log"),data = train)
model2 <- glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings) 
              + ownteam,family = poisson(link = "log"),data = train)
model3 <- glm(runs ~ balls + home + toss_win + target_if_chase + factor(innings) 
              + ownteam + opponent,family = poisson(link = "log"),data = train)

# predict the runs for the test set
test$pred1 = predict(model1,test)
test$pred2 = predict(model2,test)
test$pred3 = predict(model3,test)

# compute the prediction RMSE
test %>%
  summarize(
    RMSE1 = sqrt(mean((runs - pred1)^2)),
    RMSE2 = sqrt(mean((runs - pred2)^2)),
    RMSE3 = sqrt(mean((runs - pred3)^2))
  )

# compute the AIC values
model1$aic; model2$aic; model3$aic

# number of parameters
length(model1$coefficients); length(model2$coefficients); length(model3$coefficients)
