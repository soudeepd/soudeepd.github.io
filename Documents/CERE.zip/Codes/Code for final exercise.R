
############################ DATA READING 

# load libraries as required
library(ggplot2)
library(tidyverse)
library(forecast)
library(ggpubr)
library(glmnet)
library(MASS)
library(nnet)
library(class)
library(readxl)

# fix your working directory
setwd("...")

# read train and test datasets
train = read_xlsx("For hands-on exercise/train.xlsx")
test = read_xlsx("For hands-on exercise/validation.Xlsx")


# create categorical outcome variables w.r.t. the home team
train = train %>%
  mutate(
    result = ifelse(home_team_score > away_team_score,"H",
                    ifelse(home_team_score == away_team_score,"D","A"))
  )


######### CLASSIFICATION ALGORITHMS WITH TRAINING AND VALIDATION SETS

# how to split the data
n.train = nrow(train)
n.validation = floor(n.train*0.1)

# divide in training and validation
set.seed(1)
validation.idx = sample(n.train, n.validation)
training.idx = setdiff(c(1:n.train),validation.idx)

training.set = train[training.idx,]
validation.set = train[validation.idx,]

# we can try many features: for this exploration, let's only use the betting odds

# try LDA, QDA, GLM, random guess, home win prediction
lda.fit = lda(result ~ home_odds + draw_odds + away_odds,
              data = train,subset = training.idx)
validation.set$LDA_pred = predict(lda.fit,validation.set)$class

qda.fit = qda(result ~ home_odds + draw_odds + away_odds,
              data = train,subset = training.idx)
validation.set$QDA_pred = predict(qda.fit,validation.set)$class

glm.fit = multinom(result ~ home_odds + draw_odds + away_odds,
                   data = training.set)
validation.set$GLM_pred = predict(glm.fit,newdata = validation.set)

validation.set$random_pred = sample(x = c('A','D','H'),
                                    size = n.validation,
                                    replace = T)
validation.set$naive_pred = "H"


# check the accuracy of different methods
validation.set %>%
  summarize(
    LDA_acc = mean(LDA_pred == result),
    QDA_acc = mean(QDA_pred == result),
    GLM_acc = mean(GLM_pred == result),
    RANDOM_acc = mean(random_pred == result),
    NAIVE_acc = mean(naive_pred == result)
  )


# run KNN and see the results
train.X = as.matrix(training.set[,c('home_odds','draw_odds','away_odds')])
validation.X = as.matrix(validation.set[,c('home_odds','draw_odds','away_odds')])
train.Direction = training.set$result

set.seed (1)
validation.set$knn.pred.1 = knn(train.X,validation.X,train.Direction,k = 1)
set.seed (1)
validation.set$knn.pred.3 = knn(train.X,validation.X,train.Direction,k = 3)
set.seed (1)
validation.set$knn.pred.9 = knn(train.X,validation.X,train.Direction,k = 9)
set.seed (1)
validation.set$knn.pred.27 = knn(train.X,validation.X,train.Direction,k = 27)
validation.set %>%
  summarize(
    KNN1_acc = mean(knn.pred.1 == result),
    KNN3_acc = mean(knn.pred.3 == result),
    KNN9_acc = mean(knn.pred.9 == result),
    KNN27_acc = mean(knn.pred.27 == result)
  )


######### HANDS-ON EXERCISE
