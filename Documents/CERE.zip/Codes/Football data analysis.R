
############################ EPL DATA READING 

# load libraries as required
library(ggplot2)
library(tidyverse)

# fix your working directory
setwd("...")

# read all datasets
matchsummary = read.csv("Football-EPL/matchsummary.csv")
matchdetails = read.csv("Football-EPL/matchdetails.csv")
incidents = read.csv("Football-EPL/all_incidents.csv")
player_details = read.csv("Football-EPL/player_details.csv")
players = read.csv("Football-EPL/players.csv")


############################ MANCHESTER UNITED AND DDG

# get manchester united matches
manutd_matches = matchsummary %>% 
  filter(home_team == 'Manchester United' | away_team == 'Manchester United')
manutd_matchids = manutd_matches$match_api_id
manutd_id = ifelse(manutd_matches$home_team[1] == 'Manchester United',
                   manutd_matches$home_team_api_id[1],
                   manutd_matches$away_team_api_id[1])

# get david de gea player id
ddg_id = players$player_api_id[which(players$player_name == 'David De Gea')]

# create a data-frame for only manchester united matches with necessary information
ex1.df = manutd_matches %>%
  mutate(
    date = as.Date(date,format = '%d/%m/%y'),
    opponent = ifelse(home_team == 'Manchester United',away_team,home_team),
    opponent_api_id = ifelse(home_team == 'Manchester United',away_team_api_id,home_team_api_id),
    home = ifelse(home_team == 'Manchester United',1,0),
    own_score = ifelse(home_team == 'Manchester United',home_team_goal,away_team_goal),
    opponent_score = ifelse(home_team == 'Manchester United',away_team_goal,home_team_goal),
    result = ifelse(own_score > opponent_score,'win',ifelse(own_score == opponent_score,'draw','loss')),
    own_strength = ifelse(home_team == 'Manchester United',home_overall,away_overall),
    opponent_strength = ifelse(home_team == 'Manchester United',away_overall,home_overall)
  ) %>%
  dplyr::select(season,date,match_api_id,opponent,opponent_api_id,home,
                own_strength,opponent_strength,own_score,opponent_score,result)

# add a column for reflecting the goalkeeper name
ex1.df$goalkeeper = sapply(ex1.df$match_api_id,FUN = function(x){
  matchdata = matchdetails %>% filter(match_api_id == x)
  gk_id = ifelse(matchdata$home_team_api_id == manutd_id,
                 matchdata$home_player_1,
                 matchdata$away_player_1)
  subset(players,player_api_id == gk_id)$player_name
})


# HANDS-ON EXERCISE: Use the above data to answer the question about David de Gea.

# one possible solution
ex1.df %>%
  group_by(goalkeeper) %>%
  summarise(
    count = n(),
    win = mean(result == 'win'),
    draw = mean(result == 'draw'),
    loss = mean(result == 'loss'),
    avg.goals.conceded = mean(opponent_score)
  ) %>%
  mutate_if(is.numeric,round,digits = 3) %>%
  View()


############################ RADAR CHART 

# objective: compare different skills for Ronaldo and Messi using radar chart

# need the following package
devtools::install_github("ricardo-bion/ggradar")
library(ggradar)

# extract information about the two players
id1 = players$player_api_id[which(players$player_name == 'Cristiano Ronaldo')]
id2 = players$player_api_id[which(players$player_name == 'Lionel Messi')]

ronaldo = player_details %>% filter(player_api_id == id1)
messi = player_details %>% filter(player_api_id == id2)

# let's compare the following ten skills: 
# "crossing","finishing","heading_accuracy","short_passing","long_passing",
# "volleys","dribbling","curve","free_kick_accuracy","ball_control"

variables = c("crossing","finishing","heading_accuracy","short_passing","long_passing",
              "volleys","dribbling","curve","free_kick_accuracy","ball_control")
plot.data = data.frame(
  player = c('Cristiano Ronaldo','Lionel Messi'),
  rbind(colMeans(ronaldo[,variables]),colMeans(messi[,variables])),
  stringsAsFactors = T
)

ggradar(
  plot.data,
  values.radar = c('0','50','100'),
  grid.min = 0, grid.mid = 50, grid.max = 100,
  axis.label.size = 3,
  legend.position = 'bottom'
)

############################ VIOLIN PLOT
    
# objective: compare overall ratings of Manchester United players across seasons

ex1.df %>%
  ggplot(aes(x = season,y = own_strength)) + 
  geom_violin() +
  geom_boxplot(width = 0.1)


############################ SPATIAL HOTSPOT/HEATMAP 

# read all incidents data
epl = read.csv("Football-EPL/all_incidents.csv")

# find the subset where lat-lon information is available
events_latlon = epl %>% filter(!is.na(lat))

# which events are there with lat-lon information
table(events_latlon$type)

# create a map of shots on target and off target
library(RColorBrewer) # for color selection
shoton_plot = events_latlon %>%
  group_by(lon,lat) %>%
  summarize(
    shoton = sum(type == 'shoton'),
    shotoff = sum(type == 'shotoff')
  ) %>%
  filter(shoton > 0) %>%
  ggplot(aes(x = lon,y = lat)) + 
  stat_density2d(aes(fill =..level..),geom = "polygon") + 
  scale_fill_gradientn(colours = rev(brewer.pal(7, "Spectral"))) +
  ggtitle("on target") +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15),
        legend.position = "bottom",
        legend.text = element_text(size = 5),
        legend.title = element_blank())

shotoff_plot = events_latlon %>%
  group_by(lon,lat) %>%
  summarize(
    shoton = sum(type == 'shoton'),
    shotoff = sum(type == 'shotoff')
  ) %>%
  filter(shotoff > 0) %>%
  ggplot(aes(x = lon,y = lat)) + 
  stat_density2d(aes(fill =..level..),geom = "polygon") + 
  scale_fill_gradientn(colours = rev(brewer.pal(7, "Spectral"))) +
  ggtitle("off target") +
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 15),
        legend.position = "bottom",
        legend.text = element_text(size = 5),
        legend.title = element_blank())

# merge the two plots
shotonoff_heatmap = ggpubr::ggarrange(shoton_plot,shotoff_plot,nrow = 1,ncol = 2,
                                      common.legend = T,legend = "bottom")

# view the plot
shotonoff_heatmap
